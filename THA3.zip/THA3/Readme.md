# THA3 - PA1
Genarally most things are explained in PA1.m

# Folders
### data_given
    -   assignment dataset. Hopefully untouched.
### data_out
    -   output data created directly from the PA1.m script
### HW3-PA2
    -   PA2 assignement files
### src
    -   function scripts for general use